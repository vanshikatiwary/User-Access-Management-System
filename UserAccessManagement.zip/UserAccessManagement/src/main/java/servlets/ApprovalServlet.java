package servlets;

import java.io.IOException;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/ApprovalServlet")
public class ApprovalServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String approvedId = request.getParameter("approve");
        String rejectedId = request.getParameter("reject");

        int requestId = -1;
        String newStatus = "";

        if (approvedId != null) {
            requestId = Integer.parseInt(approvedId);
            newStatus = "Approved";
        } else if (rejectedId != null) {
            requestId = Integer.parseInt(rejectedId);
            newStatus = "Rejected";
        }

        try {
            Class.forName("org.postgresql.Driver");
            Connection conn = DriverManager.getConnection(
                "jdbc:postgresql://localhost:5432/user_access_db", "postgres", "Kaka1101");

            String query = "UPDATE requests SET status = ? WHERE id = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, newStatus);
            stmt.setInt(2, requestId);
            stmt.executeUpdate();

            stmt.close();
            conn.close();

            response.sendRedirect("pendingRequests.jsp");

        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println("Error: " + e.getMessage());
        }
    }
}

