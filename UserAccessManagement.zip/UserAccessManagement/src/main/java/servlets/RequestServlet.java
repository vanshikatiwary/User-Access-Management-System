package servlets;

import java.io.IOException;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/RequestServlet")
public class RequestServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {

        // Get form parameters
        int softwareId = Integer.parseInt(request.getParameter("softwareId"));
        String accessType = request.getParameter("accessType");
        String reason = request.getParameter("reason");

        // Get logged-in username from session
        HttpSession session = request.getSession(false); // safer: don't create session if not present
        String username = (session != null) ? (String) session.getAttribute("username") : null;

        if (username == null) {
            response.getWriter().println("❌ Error: User not logged in.");
            return;
        }

        try {
            // Connect to PostgreSQL
            Class.forName("org.postgresql.Driver");
            Connection conn = DriverManager.getConnection(
                "jdbc:postgresql://localhost:5432/user_access_db", "postgres", "Kaka1101");

            // Get user_id using username
            String getUserQuery = "SELECT id FROM users WHERE username = ?";
            PreparedStatement getUserStmt = conn.prepareStatement(getUserQuery);
            getUserStmt.setString(1, username);
            ResultSet rs = getUserStmt.executeQuery();

            int userId = -1;
            if (rs.next()) {
                userId = rs.getInt("id");
            } else {
                response.getWriter().println("❌ Error: User not found in database.");
                return;
            }

            // Insert access request
            String insertQuery = "INSERT INTO requests (user_id, software_id, access_type, reason, status) VALUES (?, ?, ?, ?, 'Pending')";
            PreparedStatement stmt = conn.prepareStatement(insertQuery);
            stmt.setInt(1, userId);
            stmt.setInt(2, softwareId);
            stmt.setString(3, accessType);
            stmt.setString(4, reason);
            stmt.executeUpdate();

            // Cleanup
            stmt.close();
            getUserStmt.close();
            conn.close();

            // ✅ Success message
            response.getWriter().println("✅ Access request submitted successfully!");

        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println("❌ Error: " + e.getMessage());
        }
    }
}

               

           